import 'package:firebase_core/firebase_core.dart';

const FirebaseOptions firebaseOptions = FirebaseOptions(
  apiKey: "AIzaSyCMAXIDFSiWglfbI7GVD_mpadHoLXRJbuo",
  appId: "1:633473238660:android:5017bf5fe38c71bae7a4d1",
  messagingSenderId: "633473238660",
  projectId: "smart-chef-e2e04",
  storageBucket: "smart-chef-e2e04.appspot.com",
);
