import 'package:flutter/material.dart';
import 'package:smart_chef/firebase_core.dart';
import 'package:smart_chef/screens/diet_planner_screen.dart';
import 'package:smart_chef/screens/pantry_screen.dart';
import 'package:smart_chef/screens/profile_screen.dart';
import 'package:smart_chef/screens/shopping_list_screen.dart';
import 'screens/dashboard_screen.dart';
import 'package:firebase_core/firebase_core.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: firebaseOptions,
  );
  runApp( MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Smart Chef',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: Text('Smart Chef'),
        ),
        body: Center(
          child: Text('Firebase działa! 🎉'),
        ),
      ),
    );
  }
}