package com.example.smart_chef

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
